Program name: WALDIM

Manuscript: "WALDIM: A code for the dimensionality analysis of magnetotelluric data using the Rotational Invariants of the Magnetotelluric Tensor"
Authors: A. Mart�, P. Queralt and J. Ledo
Submitted to Computers and Geosciences. 2008-2009