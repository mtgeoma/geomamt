
C
C                        CONSTANT
C
      Real*8 Pi,Mue,CondAir
      Real*8 D0,D1,D2,D3,D4,D5,D6,D7,D8,D9,D10,D90,D100,D180

      Common /CONST/  Pi,Mue,CondAir
      Common /NUMBER/ D0,D1,D2,D3,D4,D5,D6,D7,D8,D9,D10,
     >                D90,D100,D180


