EMTF_DIR = '/home/maxwell/progs/EMTF/';
dir = [ EMTF_DIR 'matlab/'];
path([dir 'IN'],path);
path([dir 'PW'],path);
path([dir 'SDM'],path);
path([dir 'UTIL'],path);
path([dir 'ZPLT'],path);
