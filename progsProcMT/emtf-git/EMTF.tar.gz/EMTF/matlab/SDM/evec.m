[hfig_evec] = evec_plt(ib,ivec,rho_ref);
