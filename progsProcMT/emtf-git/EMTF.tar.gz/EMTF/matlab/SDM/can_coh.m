global ind1 ind2
h_check = ch_menu(chid,csta);
