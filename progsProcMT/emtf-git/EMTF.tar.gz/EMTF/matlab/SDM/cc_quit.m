global hfig_can_coh_menu
delete(hfig_can_coh_menu);
clear hfig_can_coh_menu;
chk_clr(hfig_cc);
if( exist('hfig_cc') )
   clear hfig_cc;
end
