delete(h_pwdialog);
for h = h_plots
   delete(h);
end
