%  just a few things to set up a new figure
T = pw.T;
labels = [];
ifref = [];
v1 = [];
sig_v1 = [];
pwstmon;

plot_tf;
